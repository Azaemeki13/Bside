import { Injectable, signal } from '@angular/core';

export interface Playlist {
  name: string;
  description: string;
  cover: string | null;
}

@Injectable({ providedIn: 'root' })
export class PlaylistService {
  playlists = signal<Playlist[]>([]);
  selectedPlaylist = signal<Playlist | null>(null);

  add(playlist: Playlist): void {
    this.playlists.update(list => [...list, playlist]);
  }

  select(playlist: Playlist): void {
    this.selectedPlaylist.set(playlist);
  }
}