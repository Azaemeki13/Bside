import { Component, inject } from '@angular/core';
import { PlaylistService } from '../../services/playlist.service';

@Component({
  selector: 'app-song-list',
  imports: [],
  templateUrl: './song-list.html',
  styleUrl: './song-list.scss',
})
export class SongList {
  protected playlistService = inject(PlaylistService);
}