export interface LoginPayload {
    identifier: string;
    password: string;
}

export interface RegisterPayload {
    username: string;
    email: string;
    password: string;
}

export interface AuthResponse {
    user: {
        id: string;
        username: string;
        email: string;
        role: string;
        avatar_url: string;
    };
    token: string;
}

export interface UserProfile {
    id: string;
    username: string;
    email: string;
    role: string;
    avatar_url?: string;
}